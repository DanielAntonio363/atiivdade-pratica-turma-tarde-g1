package org.senai.exemplos;

// Superclasse
public abstract class Produto {
    private double nome;
    private double preco;


    public double calcularDesconto(double percentual) {

        double desconto = preco * percentual;
        return preco - desconto;
    }

    public void exibirInfo() {
        System.out.println("Produto: " + nome + " - Preço: " + preco);
    }
}
